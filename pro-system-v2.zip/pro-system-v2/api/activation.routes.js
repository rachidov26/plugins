import { jsonOk, jsonError, ErrorCodes } from "../shared/errors.js";
import { checkRateLimit, getClientIp } from "../shared/rateLimit.js";

export async function handleActivate(request, env, ctx) {
  const rl = await checkRateLimit(env, `rl:activation:${getClientIp(request)}`, 5, 15 * 60 * 1000);
  if (!rl.allowed) {
    return jsonError(ErrorCodes.RATE_LIMITED, "محاولات كثيرة جدًا", { "Retry-After": String(rl.retryAfterSeconds) });
  }

  let body;
  try {
    body = await request.json();
  } catch {
    return jsonError(ErrorCodes.INVALID_BODY, "جسم الطلب غير صالح");
  }

  const { key, email, biosId } = body || {};
  if (!key || !email || !biosId) {
    return jsonError(ErrorCodes.INVALID_BODY, "key وemail وbiosId مطلوبة جميعًا");
  }

  const result = await ctx.activationService.activate({ key, email, biosId, ip: getClientIp(request) });
  if (result.error) return jsonError(result.error, "فشل التفعيل");

  return jsonOk({ token: result.token, expiresAt: result.expiresAt, planId: result.planId });
}
