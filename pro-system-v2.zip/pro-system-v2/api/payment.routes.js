import { jsonOk, jsonError, ErrorCodes } from "../shared/errors.js";
import { checkRateLimit, getClientIp } from "../shared/rateLimit.js";
import { PaymentStatus } from "../d1/paymentRepository.js";

export async function handleCreateOrder(request, env, ctx) {
  const rl = await checkRateLimit(env, `rl:payment:create:${getClientIp(request)}`, 20, 60 * 1000);
  if (!rl.allowed) return jsonError(ErrorCodes.RATE_LIMITED, "محاولات كثيرة جدًا", { "Retry-After": String(rl.retryAfterSeconds) });

  let body;
  try {
    body = await request.json();
  } catch {
    return jsonError(ErrorCodes.INVALID_BODY, "جسم الطلب غير صالح");
  }

  const result = await ctx.paymentService.createOrder(body?.offerKey);
  if (result.error) return jsonError(result.error, "تعذّر إنشاء طلب الدفع");
  return jsonOk({ orderId: result.orderId });
}

export async function handleCaptureOrder(request, env, ctx) {
  const rl = await checkRateLimit(env, `rl:payment:capture:${getClientIp(request)}`, 20, 60 * 1000);
  if (!rl.allowed) return jsonError(ErrorCodes.RATE_LIMITED, "محاولات كثيرة جدًا", { "Retry-After": String(rl.retryAfterSeconds) });

  let body;
  try {
    body = await request.json();
  } catch {
    return jsonError(ErrorCodes.INVALID_BODY, "جسم الطلب غير صالح");
  }

  const { orderId, offerKey } = body || {};
  if (!orderId || !offerKey) return jsonError(ErrorCodes.INVALID_BODY, "orderId وofferKey مطلوبان");

  const captureResult = await ctx.paymentService.captureOrder(orderId);
  if (captureResult.error) return jsonError(captureResult.error, "فشل تأكيد الدفع");

  const capture = captureResult.data.purchase_units?.[0]?.payments?.captures?.[0];
  if (!capture || capture.status !== "COMPLETED") {
    return jsonError(ErrorCodes.PAYMENT_VERIFICATION_FAILED, "الدفع لم يكتمل بعد");
  }

  const result = await ctx.paymentService.processCompletedCapture({
    captureId: capture.id,
    orderId,
    offerKey,
    amount: capture.amount?.value,
    currency: capture.amount?.currency_code,
    buyerEmail: captureResult.data.payer?.email_address || null
  });

  if (result.error) return jsonError(result.error, "تعذّر إتمام العملية");
  if (result.alreadyProcessed) return jsonOk({ alreadyProcessed: true });

  return jsonOk({ licenseKey: result.licenseKey, expiryDate: result.expiryDate, emailSent: result.emailSent });
}

const REFUND_EVENT_TYPES = {
  "PAYMENT.CAPTURE.REFUNDED": PaymentStatus.REFUNDED,
  "PAYMENT.CAPTURE.REVERSED": PaymentStatus.REVERSED,
  "CUSTOMER.DISPUTE.CREATED": PaymentStatus.DISPUTED
};

/** يستخرج معرّف الـcapture الأصلي من روابط PayPal (rel: "up") لأحداث الاسترجاع */
function extractOriginalCaptureId(resource) {
  const upLink = (resource.links || []).find((l) => l.rel === "up");
  if (!upLink) return null;
  const match = upLink.href.match(/\/payments\/captures\/([A-Za-z0-9]+)/);
  return match ? match[1] : null;
}

export async function handleWebhook(request, env, ctx) {
  const rawBody = await request.text();

  let isValid = false;
  try {
    isValid = await ctx.paymentService.verifyWebhookSignature(request, rawBody);
  } catch {
    return jsonError(ErrorCodes.PAYMENT_VERIFICATION_FAILED, "تعذّر التحقق من التوقيع");
  }
  if (!isValid) return jsonError(ErrorCodes.PAYMENT_VERIFICATION_FAILED, "توقيع غير صالح");

  const event = JSON.parse(rawBody);

  if (event.event_type === "PAYMENT.CAPTURE.COMPLETED" && event.resource?.status === "COMPLETED") {
    const result = await ctx.paymentService.processCompletedCapture({
      captureId: event.resource.id,
      orderId: event.resource.supplementary_data?.related_ids?.order_id || null,
      offerKey: "pro_standard", // عرض وحيد حاليًا — سيحتاج تمرير صريح عند تعدد العروض مستقبلًا
      amount: event.resource.amount?.value,
      currency: event.resource.amount?.currency_code,
      buyerEmail: event.resource.payer?.email_address || null
    });
    return jsonOk({ licenseCreated: !result.alreadyProcessed && !result.error });
  }

  if (REFUND_EVENT_TYPES[event.event_type]) {
    const originalCaptureId = extractOriginalCaptureId(event.resource) || event.resource?.id;
    const result = await ctx.paymentService.processRefundOrReversal(
      originalCaptureId,
      REFUND_EVENT_TYPES[event.event_type]
    );
    return jsonOk({ handled: !result.error });
  }

  return jsonOk({ ignored: true });
}
