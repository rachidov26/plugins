import { jsonOk, jsonError, ErrorCodes } from "../shared/errors.js";

function getBearerToken(request) {
  const header = request.headers.get("Authorization") || "";
  const match = header.match(/^Bearer\s+(.+)$/i);
  return match ? match[1] : null;
}

export async function handleProfile(request, env, ctx) {
  const token = getBearerToken(request);
  const rawBiosId = request.headers.get("X-Device-Id");
  if (!token || !rawBiosId) return jsonError(ErrorCodes.INVALID_TOKEN, "التوكن أو معرّف الجهاز مفقود");

  const result = await ctx.sessionService.validate(token, rawBiosId);
  if (result.error) return jsonError(result.error, "تعذّر عرض الملف الشخصي");

  const profile = ctx.profileService.build(result.license, result.status);
  return jsonOk({ profile });
}
