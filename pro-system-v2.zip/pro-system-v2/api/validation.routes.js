import { jsonOk, jsonError, ErrorCodes } from "../shared/errors.js";
import { checkRateLimit, getClientIp } from "../shared/rateLimit.js";

function getBearerToken(request) {
  const header = request.headers.get("Authorization") || "";
  const match = header.match(/^Bearer\s+(.+)$/i);
  return match ? match[1] : null;
}

export async function handleValidate(request, env, ctx) {
  const rl = await checkRateLimit(env, `rl:validation:${getClientIp(request)}`, 120, 60 * 1000);
  if (!rl.allowed) return jsonError(ErrorCodes.RATE_LIMITED, "محاولات كثيرة جدًا", { "Retry-After": String(rl.retryAfterSeconds) });

  const token = getBearerToken(request);
  const rawBiosId = request.headers.get("X-Device-Id");
  if (!token || !rawBiosId) return jsonError(ErrorCodes.INVALID_TOKEN, "التوكن أو معرّف الجهاز مفقود");

  const result = await ctx.sessionService.validate(token, rawBiosId);
  if (result.error) return jsonError(result.error, "التحقق فشل");

  return jsonOk({ valid: true, status: result.status, planId: result.license.planId });
}
