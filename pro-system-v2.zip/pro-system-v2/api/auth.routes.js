import { jsonOk, jsonError, ErrorCodes } from "../shared/errors.js";
import { checkRateLimit, getClientIp } from "../shared/rateLimit.js";

function getBearerToken(request) {
  const header = request.headers.get("Authorization") || "";
  const match = header.match(/^Bearer\s+(.+)$/i);
  return match ? match[1] : null;
}

export async function handleRenew(request, env, ctx) {
  const rl = await checkRateLimit(env, `rl:renew:${getClientIp(request)}`, 30, 60 * 1000);
  if (!rl.allowed) return jsonError(ErrorCodes.RATE_LIMITED, "محاولات كثيرة جدًا", { "Retry-After": String(rl.retryAfterSeconds) });

  const token = getBearerToken(request);
  const rawBiosId = request.headers.get("X-Device-Id");
  if (!token || !rawBiosId) return jsonError(ErrorCodes.INVALID_TOKEN, "التوكن أو معرّف الجهاز مفقود");

  const result = await ctx.sessionService.renew(token, rawBiosId);
  if (result.error) return jsonError(result.error, "فشل تجديد الجلسة");

  return jsonOk({ token: result.token, expiresAt: result.expiresAt, planId: result.planId });
}
