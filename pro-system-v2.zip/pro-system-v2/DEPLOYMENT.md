# النشر

## 1. طبّق تعديلات D1 أولًا (ملف d1-proposed-changes.txt المُرسَل سابقًا)
على الأقل: ALTER TABLE licenses ADD COLUMN revokedAt TEXT;

## 2. الأسرار المطلوبة (جديدة كليًا، منفصلة عن أي نظام سابق)
```
wrangler secret put SESSION_SIGNING_KEYS --name veltrix-pro-system
# القيمة: JSON مثل {"k1":"<32+ حرفًا عشوائيًا>"}

wrangler secret put SESSION_ACTIVE_KID --name veltrix-pro-system
# القيمة: k1

wrangler secret put PAYPAL_CLIENT_ID --name veltrix-pro-system
wrangler secret put PAYPAL_CLIENT_SECRET --name veltrix-pro-system
wrangler secret put PAYPAL_WEBHOOK_ID --name veltrix-pro-system
wrangler secret put RESEND_API_KEY --name veltrix-pro-system
```

## 3. النشر
```
wrangler deploy
```

## 4. تدوير مفتاح التوقيع مستقبلًا (بدون كسر جلسات قائمة)
1. أضف "k2" جديدًا إلى SESSION_SIGNING_KEYS: {"k1":"...","k2":"..."}
2. غيّر SESSION_ACTIVE_KID إلى "k2"
3. انتظر 20 دقيقة (أطول عمر توكن ممكن) ثم احذف "k1" بأمان
