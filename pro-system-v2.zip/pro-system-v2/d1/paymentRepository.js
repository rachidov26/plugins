/** حالات صريحة للـState Machine (البند 8) — كلها نصوص تُخزَّن في عمود status الموجود أصلًا */
export const PaymentStatus = Object.freeze({
  CREATED: "CREATED",
  APPROVED: "APPROVED",
  CAPTURED: "CAPTURED",
  VERIFIED: "VERIFIED",
  LICENSE_ISSUED: "LICENSE_ISSUED",
  FAILED: "FAILED",
  REFUNDED: "REFUNDED",
  REVERSED: "REVERSED",
  DISPUTED: "DISPUTED"
});

export class PaymentRepository {
  constructor(db) {
    this.db = db;
  }

  async findByCaptureId(captureId) {
    return this.db.prepare("SELECT * FROM payment_events WHERE captureId = ?").bind(captureId).first();
  }

  async create({ captureId, orderId, planKey, amount, buyerEmail, status }) {
    return this.db
      .prepare(
        `INSERT INTO payment_events (captureId, orderId, planKey, amount, buyerEmail, license_id, status, createdAt)
         VALUES (?, ?, ?, ?, ?, NULL, ?, ?)`
      )
      .bind(captureId, orderId, planKey, amount, buyerEmail, status, new Date().toISOString())
      .run();
  }

  async setStatus(captureId, status) {
    return this.db.prepare("UPDATE payment_events SET status = ? WHERE captureId = ?").bind(status, captureId).run();
  }

  async linkLicenseAndIssue(captureId, licenseId) {
    return this.db
      .prepare("UPDATE payment_events SET license_id = ?, status = ? WHERE captureId = ?")
      .bind(licenseId, PaymentStatus.LICENSE_ISSUED, captureId)
      .run();
  }
}
