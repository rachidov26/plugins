export class LicenseRepository {
  constructor(db) {
    this.db = db;
  }

  async findByKey(key) {
    return this.db.prepare("SELECT * FROM licenses WHERE key = ?").bind(key).first();
  }

  async findById(id) {
    return this.db.prepare("SELECT * FROM licenses WHERE id = ?").bind(id).first();
  }

  async create({ id, username, key, createdAt, expiryDate, devices, planId, email }) {
    return this.db
      .prepare(
        `INSERT INTO licenses (id, username, key, createdAt, expiryDate, devices, planId, biosId, email)
         VALUES (?, ?, ?, ?, ?, ?, ?, NULL, ?)`
      )
      .bind(id, username, key, createdAt, expiryDate, devices, planId, email || null)
      .run();
  }

  /**
   * البند 11 — UPDATE شرطي ذرّي: ينجح فقط إن كان biosId لا يزال NULL فعليًا
   * لحظة التنفيذ. SQLite/D1 يُسلسل الكتابات على نفس الصف، فهذا يمنع فوز
   * طلبين متزامنين معًا فعليًا (ليس تخمينًا، بل ضمان من محرك القاعدة نفسه).
   *
   * @returns {changes: number} — 1 = نجح هذا الطلب تحديدًا بالربط الأول.
   *                              0 = صف آخر (أو نفس الطلب مكررًا) سبقه بالفعل.
   */
  async bindDeviceIfUnbound(licenseId, biosIdHash) {
    return this.db
      .prepare("UPDATE licenses SET biosId = ? WHERE id = ? AND biosId IS NULL")
      .bind(biosIdHash, licenseId)
      .run();
  }

  /** إبطال حقيقي في D1 — مصدر الحقيقة الوحيد (لا KV) */
  async revoke(licenseId) {
    return this.db
      .prepare("UPDATE licenses SET revokedAt = ? WHERE id = ?")
      .bind(new Date().toISOString(), licenseId)
      .run();
  }
}
