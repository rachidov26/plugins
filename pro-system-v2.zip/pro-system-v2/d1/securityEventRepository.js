/**
 * SecurityEventRepository
 * ----------------------------------------------------------------------------
 * ⚠️ يفترض وجود جدول security_events (مقترَح في d1-proposed-changes.txt).
 * إن لم يُنشَأ الجدول بعد، كل استدعاء هنا يفشل بصمت (try/catch) — لا يُسقط
 * أي طلب حقيقي بسبب غياب جدول تدقيق اختياري.
 */
export class SecurityEventRepository {
  constructor(db) {
    this.db = db;
  }

  async record(eventType, { licenseId = null, requestId = null, ip = null } = {}) {
    try {
      await this.db
        .prepare(
          `INSERT INTO security_events (event_type, license_id, request_id, ip, created_at)
           VALUES (?, ?, ?, ?, ?)`
        )
        .bind(eventType, licenseId, requestId, ip, new Date().toISOString())
        .run();
    } catch {
      /* الجدول قد لا يكون موجودًا بعد — غير حرج إطلاقًا */
    }
  }
}
