export class ActivationLogRepository {
  constructor(db) {
    this.db = db;
  }

  async record({ licenseId, biosIdHash, result, ip }) {
    try {
      await this.db
        .prepare(
          `INSERT INTO activation_log (license_id, bios_id_hash, result, ip, created_at)
           VALUES (?, ?, ?, ?, ?)`
        )
        .bind(licenseId, biosIdHash || null, result, ip || null, new Date().toISOString())
        .run();
    } catch {
      /* التسجيل ثانوي — لا يجب أن يُفشل التفعيل نفسه */
    }
  }
}
