import { LicenseRepository } from "./d1/licenseRepository.js";
import { PaymentRepository } from "./d1/paymentRepository.js";
import { ActivationLogRepository } from "./d1/activationLogRepository.js";
import { SecurityEventRepository } from "./d1/securityEventRepository.js";

import { KeyManager } from "./services/keyManager.js";
import { SessionTokenService } from "./services/sessionTokenService.js";
import { LicenseStatusService } from "./services/licenseStatusService.js";
import { PaymentService } from "./services/paymentService.js";
import { ActivationService } from "./services/activationService.js";
import { SessionService } from "./services/sessionService.js";
import { ProfileService } from "./services/profileService.js";
import { createEmailSender } from "./services/emailService.js";

import { handleCreateOrder, handleCaptureOrder, handleWebhook } from "./api/payment.routes.js";
import { handleActivate } from "./api/activation.routes.js";
import { handleRenew } from "./api/auth.routes.js";
import { handleValidate } from "./api/validation.routes.js";
import { handleProfile } from "./api/profile.routes.js";
import { jsonError, ErrorCodes } from "./shared/errors.js";

function buildContext(env) {
  const licenseRepo = new LicenseRepository(env.DB);
  const paymentRepo = new PaymentRepository(env.DB);
  const activationLogRepo = new ActivationLogRepository(env.DB);
  const securityEventRepo = new SecurityEventRepository(env.DB);

  const keyManager = new KeyManager(env);
  const sessionTokenService = new SessionTokenService(keyManager);
  const statusService = new LicenseStatusService();
  const sendLicenseEmail = createEmailSender(env);

  const paymentService = new PaymentService({ env, paymentRepo, licenseRepo, sendLicenseEmail, securityEventRepo });
  const activationService = new ActivationService({
    licenseRepo, statusService, sessionTokenService, activationLogRepo, securityEventRepo
  });
  const sessionService = new SessionService({ sessionTokenService, licenseRepo, statusService, securityEventRepo });
  const profileService = new ProfileService();

  return { paymentService, activationService, sessionService, profileService };
}

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    const path = url.pathname;
    const method = request.method;
    const ctx = buildContext(env);

    try {
      if (path === "/api/v1/payment/create-order" && method === "POST") return handleCreateOrder(request, env, ctx);
      if (path === "/api/v1/payment/capture-order" && method === "POST") return handleCaptureOrder(request, env, ctx);
      if (path === "/api/v1/payment/webhook" && method === "POST") return handleWebhook(request, env, ctx);

      if (path === "/api/v1/activation/activate" && method === "POST") return handleActivate(request, env, ctx);
      if (path === "/api/v1/auth/renew" && method === "POST") return handleRenew(request, env, ctx);
      if (path === "/api/v1/validation/check" && method === "GET") return handleValidate(request, env, ctx);
      if (path === "/api/v1/profile/me" && method === "GET") return handleProfile(request, env, ctx);

      return jsonError(ErrorCodes.INVALID_BODY, "مسار غير موجود");
    } catch {
      return jsonError(ErrorCodes.INTERNAL_ERROR, "حدث خطأ داخلي");
    }
  }
};
