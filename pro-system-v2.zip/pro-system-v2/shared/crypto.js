export function bufferToBase64Url(buffer) {
  const bytes = new Uint8Array(buffer);
  let binary = "";
  for (const b of bytes) binary += String.fromCharCode(b);
  return btoa(binary).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
}

export function base64UrlToString(str) {
  let s = str.replace(/-/g, "+").replace(/_/g, "/");
  while (s.length % 4) s += "=";
  return atob(s);
}

export function stringToBase64Url(str) {
  return btoa(str).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
}

export async function hmacSign(secret, message) {
  const key = await crypto.subtle.importKey(
    "raw",
    new TextEncoder().encode(secret),
    { name: "HMAC", hash: "SHA-256" },
    false,
    ["sign"]
  );
  const sig = await crypto.subtle.sign("HMAC", key, new TextEncoder().encode(message));
  return bufferToBase64Url(sig);
}

export async function sha256Hex(input) {
  const buf = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(input));
  return [...new Uint8Array(buf)].map((b) => b.toString(16).padStart(2, "0")).join("");
}

export function timingSafeEqual(a, b) {
  if (typeof a !== "string" || typeof b !== "string" || a.length !== b.length) return false;
  let diff = 0;
  for (let i = 0; i < a.length; i++) diff |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return diff === 0;
}

export function normalizeBiosId(rawBiosId) {
  return String(rawBiosId).trim().toUpperCase();
}

export async function hashBiosId(rawBiosId) {
  return sha256Hex(normalizeBiosId(rawBiosId));
}

export function generateSecureLicenseKey() {
  const charset = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"; // بدون أحرف متشابهة (O/0, I/1)
  const group = (n) => {
    const bytes = crypto.getRandomValues(new Uint8Array(n));
    return Array.from(bytes, (b) => charset[b % charset.length]).join("");
  };
  return `RACHID-${group(5)}-${group(5)}-${group(5)}`;
}

export function generateSecureId(prefix) {
  const randomPart = bufferToBase64Url(crypto.getRandomValues(new Uint8Array(12)).buffer);
  return `${prefix}_${Date.now()}_${randomPart}`;
}

export function generateJti() {
  return bufferToBase64Url(crypto.getRandomValues(new Uint8Array(9)).buffer);
}

// ------------------------------------------------------------------
// إخفاء بيانات حساسة للعرض (Profile) — لا تُستخدم إطلاقًا لأي مقارنة أمنية
// ------------------------------------------------------------------

export function maskLicenseKey(key) {
  if (!key || key.length < 10) return "****";
  return `${key.slice(0, 10)}****${key.slice(-4)}`;
}

export function maskEmail(email) {
  if (!email || !email.includes("@")) return "****";
  const [local, domain] = email.split("@");
  const visible = local.slice(0, 1);
  return `${visible}${"*".repeat(Math.max(3, local.length - 1))}@${domain}`;
}
