/**
 * ⚠️ هذا rate limiting دفاعي فقط (Defense in Depth)، عبر KV — غير ذرّي
 * رياضيًا بشكل صارم تحت تزامن شديد جدًا (نافذة سباق ضيقة جدًا نظريًا ممكنة).
 * هذا مقصود ومقبول: القرار الأمني الحقيقي (من يُسمح له بربط جهاز) محسوم في
 * activationService عبر UPDATE شرطي ذرّي في D1، وليس هنا. لا تعتمد على هذا
 * الملف كخط الدفاع الوحيد أو الحاسم ضد أي هجوم.
 */
export async function checkRateLimit(env, key, maxAttempts, windowMs) {
  let state;
  try {
    const raw = await env.CONFIG_KV.get(key);
    state = raw ? JSON.parse(raw) : { count: 0, windowStart: Date.now() };
  } catch {
    return { allowed: true }; // فشل KV هنا لا يمنع محاولة مشروعة — دفاعي فقط
  }

  const active = Date.now() - state.windowStart <= windowMs;
  if (active && state.count >= maxAttempts) {
    const retryAfterSeconds = Math.max(1, Math.ceil((state.windowStart + windowMs - Date.now()) / 1000));
    return { allowed: false, retryAfterSeconds };
  }

  const nextState = active
    ? { count: state.count + 1, windowStart: state.windowStart }
    : { count: 1, windowStart: Date.now() };

  try {
    await env.CONFIG_KV.put(key, JSON.stringify(nextState), { expirationTtl: Math.ceil(windowMs / 1000) });
  } catch {
    /* غير حرج */
  }

  return { allowed: true };
}

export function getClientIp(request) {
  const header = request.headers.get("CF-Connecting-IP") || request.headers.get("X-Forwarded-For") || "";
  return header.split(",")[0].trim() || "unknown";
}
