export const ErrorCodes = Object.freeze({
  INVALID_LICENSE: "INVALID_LICENSE",
  INVALID_EMAIL: "INVALID_EMAIL",
  DEVICE_NOT_AUTHORIZED: "DEVICE_NOT_AUTHORIZED",
  LICENSE_EXPIRED: "LICENSE_EXPIRED",
  LICENSE_REVOKED: "LICENSE_REVOKED",
  PENDING_ACTIVATION: "PENDING_ACTIVATION",
  INVALID_TOKEN: "INVALID_TOKEN",
  TOKEN_EXPIRED: "TOKEN_EXPIRED",
  PAYMENT_NOT_FOUND: "PAYMENT_NOT_FOUND",
  PAYMENT_ALREADY_PROCESSED: "PAYMENT_ALREADY_PROCESSED",
  PAYMENT_VERIFICATION_FAILED: "PAYMENT_VERIFICATION_FAILED",
  PAYMENT_AMOUNT_MISMATCH: "PAYMENT_AMOUNT_MISMATCH",
  INVALID_OFFER: "INVALID_OFFER",
  RATE_LIMITED: "RATE_LIMITED",
  INVALID_BODY: "INVALID_BODY",
  INTERNAL_ERROR: "INTERNAL_ERROR"
});

const STATUS_BY_CODE = {
  [ErrorCodes.INVALID_LICENSE]: 401,
  [ErrorCodes.INVALID_EMAIL]: 401,
  [ErrorCodes.DEVICE_NOT_AUTHORIZED]: 403,
  [ErrorCodes.LICENSE_EXPIRED]: 403,
  [ErrorCodes.LICENSE_REVOKED]: 403,
  [ErrorCodes.PENDING_ACTIVATION]: 403,
  [ErrorCodes.INVALID_TOKEN]: 401,
  [ErrorCodes.TOKEN_EXPIRED]: 401,
  [ErrorCodes.PAYMENT_NOT_FOUND]: 404,
  [ErrorCodes.PAYMENT_ALREADY_PROCESSED]: 200,
  [ErrorCodes.PAYMENT_VERIFICATION_FAILED]: 402,
  [ErrorCodes.PAYMENT_AMOUNT_MISMATCH]: 402,
  [ErrorCodes.INVALID_OFFER]: 400,
  [ErrorCodes.RATE_LIMITED]: 429,
  [ErrorCodes.INVALID_BODY]: 400,
  [ErrorCodes.INTERNAL_ERROR]: 500
};

const SECURITY_HEADERS = {
  "X-Content-Type-Options": "nosniff",
  "X-Frame-Options": "DENY",
  "Referrer-Policy": "no-referrer",
  "Strict-Transport-Security": "max-age=31536000; includeSubDomains",
  "Cache-Control": "no-store"
};

export function jsonOk(data, status = 200, extraHeaders = {}) {
  return new Response(JSON.stringify({ success: true, ...data }), {
    status,
    headers: { "Content-Type": "application/json; charset=UTF-8", ...SECURITY_HEADERS, ...extraHeaders }
  });
}

export function jsonError(code, message, extraHeaders = {}) {
  const status = STATUS_BY_CODE[code] || 500;
  return new Response(JSON.stringify({ success: false, code, message: message || code }), {
    status,
    headers: { "Content-Type": "application/json; charset=UTF-8", ...SECURITY_HEADERS, ...extraHeaders }
  });
}
