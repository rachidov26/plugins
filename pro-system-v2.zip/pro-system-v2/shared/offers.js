export const OFFERS = Object.freeze({
  pro_standard: {
    offerKey: "pro_standard",
    planId: "PRO-9F4D7B2A-6C1E-3A9B-8D4F-7E2C1B0A5D6F",
    amount: "3.00",
    currency: "USD",
    durationDays: 30,
    label: "PRO"
  }
});

export function getOffer(offerKey) {
  return OFFERS[offerKey] || null;
}

export function matchesOffer(offer, amount, currency) {
  return (
    !!offer &&
    Math.abs(parseFloat(amount) - parseFloat(offer.amount)) < 0.001 &&
    String(currency).toUpperCase() === offer.currency.toUpperCase()
  );
}
