/**
 * KeyManager
 * ----------------------------------------------------------------------------
 * مصدر مفاتيح توقيع الجلسة. يقرأ من Secret واحد (JSON) بدل متغيرات متفرقة،
 * حتى تتم إضافة/سحب مفاتيح دون تعديل كود:
 *
 *   env.SESSION_SIGNING_KEYS   = '{"k1":"<secret1>","k2":"<secret2>"}'
 *   env.SESSION_ACTIVE_KID     = "k2"
 *
 * عند تدوير المفتاح مستقبلًا: أضف "k3" جديد، غيّر SESSION_ACTIVE_KID إلى
 * "k3"، اترك "k2" (وحتى "k1") في القائمة لفترة سماح حتى تنتهي كل الجلسات
 * الموقّعة بها (بما أن الجلسات قصيرة العمر، فترة السماح قصيرة جدًا فعليًا).
 */
export class KeyManager {
  constructor(env) {
    let parsed = {};
    try {
      parsed = JSON.parse(env.SESSION_SIGNING_KEYS || "{}");
    } catch {
      parsed = {};
    }
    this.keys = parsed;
    this.activeKid = env.SESSION_ACTIVE_KID;
  }

  getActiveKid() {
    return this.activeKid;
  }

  getActiveSecret() {
    const secret = this.keys[this.activeKid];
    if (!secret) throw new Error("no_active_signing_key_configured");
    return secret;
  }

  /** يُستخدَم فقط للتحقق (وليس التوقيع) — يقبل أي kid معروف، نشطًا كان أو قديمًا */
  getVerificationSecret(kid) {
    return this.keys[kid] || null;
  }
}
