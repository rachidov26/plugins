import { maskLicenseKey, maskEmail } from "../shared/crypto.js";

function daysRemaining(expiryDateStr) {
  const ms = new Date(expiryDateStr).getTime() - Date.now();
  return Math.max(0, Math.ceil(ms / (24 * 60 * 60 * 1000)));
}

export class ProfileService {
  build(license, status) {
    return {
      plan: "PRO",
      licenseStatus: status,
      licenseKeyMasked: maskLicenseKey(license.key),
      purchaseEmailMasked: maskEmail(license.email),
      activationDate: license.createdAt,
      expiryDate: license.expiryDate,
      daysRemaining: daysRemaining(license.expiryDate),
      deviceBound: !!license.biosId,
      devices: license.devices
    };
  }
}
