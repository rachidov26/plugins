export const LicenseStatus = Object.freeze({
  PENDING: "PENDING",
  ACTIVE: "ACTIVE",
  EXPIRED: "EXPIRED",
  REVOKED: "REVOKED"
});

/**
 * LicenseStatusService
 * ----------------------------------------------------------------------------
 * لا يلمس KV إطلاقًا. الإبطال يُقرَأ من عمود licenses.revokedAt مباشرة —
 * إن فشلت قراءة D1 لأي سبب، الاستثناء يصعد لأعلى ويُرفض الطلب بالكامل
 * (Fail-Closed طبيعي، لأن الترخيص نفسه مصدره D1 أصلًا ولا قرار بدونه ممكن).
 */
export class LicenseStatusService {
  computeStatus(licenseRow) {
    if (licenseRow.revokedAt) return LicenseStatus.REVOKED;
    if (new Date(licenseRow.expiryDate).getTime() <= Date.now()) return LicenseStatus.EXPIRED;
    if (!licenseRow.biosId) return LicenseStatus.PENDING;
    return LicenseStatus.ACTIVE;
  }
}
