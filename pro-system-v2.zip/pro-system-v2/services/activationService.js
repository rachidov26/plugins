import { hashBiosId, timingSafeEqual } from "../shared/crypto.js";
import { ErrorCodes } from "../shared/errors.js";
import { LicenseStatus } from "./licenseStatusService.js";

export class ActivationService {
  constructor({ licenseRepo, statusService, sessionTokenService, activationLogRepo, securityEventRepo }) {
    this.licenseRepo = licenseRepo;
    this.statusService = statusService;
    this.sessionTokenService = sessionTokenService;
    this.activationLogRepo = activationLogRepo;
    this.securityEventRepo = securityEventRepo;
  }

  async activate({ key, email, biosId, ip }) {
    const biosIdHash = await hashBiosId(biosId);
    const license = await this.licenseRepo.findByKey(key);

    if (!license) {
      await this.activationLogRepo.record({ licenseId: null, biosIdHash, result: "invalid_key", ip });
      return { error: ErrorCodes.INVALID_LICENSE };
    }

    const storedEmail = (license.email || "").trim().toLowerCase();
    const providedEmail = (email || "").trim().toLowerCase();
    if (!storedEmail || storedEmail !== providedEmail) {
      await this.activationLogRepo.record({ licenseId: license.id, biosIdHash, result: "invalid_email", ip });
      return { error: ErrorCodes.INVALID_EMAIL };
    }

    const status = this.statusService.computeStatus(license);

    if (status === LicenseStatus.REVOKED) {
      await this.activationLogRepo.record({ licenseId: license.id, biosIdHash, result: "revoked", ip });
      return { error: ErrorCodes.LICENSE_REVOKED };
    }
    if (status === LicenseStatus.EXPIRED) {
      await this.activationLogRepo.record({ licenseId: license.id, biosIdHash, result: "expired", ip });
      return { error: ErrorCodes.LICENSE_EXPIRED };
    }

    if (status === LicenseStatus.PENDING) {
      // البند 11: ربط ذرّي — ينجح لطلب واحد فقط حتى تحت تزامن حقيقي
      const bindResult = await this.licenseRepo.bindDeviceIfUnbound(license.id, biosIdHash);

      if (bindResult.meta.changes === 0) {
        // خسر السباق أو أُعيد نفس الطلب — أعد القراءة لمعرفة من فاز فعليًا
        const refreshed = await this.licenseRepo.findById(license.id);
        if (!timingSafeEqual(refreshed.biosId, biosIdHash)) {
          await this.activationLogRepo.record({ licenseId: license.id, biosIdHash, result: "device_mismatch_race", ip });
          return { error: ErrorCodes.DEVICE_NOT_AUTHORIZED };
        }
        // نفس الجهاز فاز فعليًا (كان هذا طلبًا مكررًا) — نتابع بنجاح
      }
    } else if (status === LicenseStatus.ACTIVE) {
      if (!timingSafeEqual(license.biosId, biosIdHash)) {
        await this.activationLogRepo.record({ licenseId: license.id, biosIdHash, result: "device_mismatch", ip });
        return { error: ErrorCodes.DEVICE_NOT_AUTHORIZED };
      }
    }

    const { token, expiresAt } = await this.sessionTokenService.issue({
      licenseId: license.id,
      planId: license.planId,
      biosHash: biosIdHash
    });

    await this.activationLogRepo.record({ licenseId: license.id, biosIdHash, result: "success", ip });
    await this.securityEventRepo.record("activation_success", { licenseId: license.id, ip });

    return { token, expiresAt, planId: license.planId };
  }
}
