import { getOffer, matchesOffer } from "../shared/offers.js";
import { generateSecureId, generateSecureLicenseKey } from "../shared/crypto.js";
import { ErrorCodes } from "../shared/errors.js";
import { PaymentStatus } from "../d1/paymentRepository.js";

const PAYPAL_API_BASE = "https://api-m.paypal.com"; // استخدم .sandbox. أثناء الاختبار

export class PaymentService {
  constructor({ env, paymentRepo, licenseRepo, sendLicenseEmail, securityEventRepo }) {
    this.env = env;
    this.paymentRepo = paymentRepo;
    this.licenseRepo = licenseRepo;
    this.sendLicenseEmail = sendLicenseEmail;
    this.securityEventRepo = securityEventRepo;
  }

  async getAccessToken() {
    const credentials = btoa(`${this.env.PAYPAL_CLIENT_ID}:${this.env.PAYPAL_CLIENT_SECRET}`);
    const res = await fetch(`${PAYPAL_API_BASE}/v1/oauth2/token`, {
      method: "POST",
      headers: { Authorization: `Basic ${credentials}`, "Content-Type": "application/x-www-form-urlencoded" },
      body: "grant_type=client_credentials"
    });
    if (!res.ok) throw new Error("paypal_auth_failed");
    return (await res.json()).access_token;
  }

  async createOrder(offerKey) {
    const offer = getOffer(offerKey);
    if (!offer) return { error: ErrorCodes.INVALID_OFFER };

    const accessToken = await this.getAccessToken();
    const res = await fetch(`${PAYPAL_API_BASE}/v2/checkout/orders`, {
      method: "POST",
      headers: { Authorization: `Bearer ${accessToken}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        intent: "CAPTURE",
        purchase_units: [{ amount: { currency_code: offer.currency, value: offer.amount } }]
      })
    });
    if (!res.ok) return { error: ErrorCodes.PAYMENT_VERIFICATION_FAILED };

    const order = await res.json();
    await this.securityEventRepo.record("payment_order_created", {});
    return { orderId: order.id };
  }

  async verifyWebhookSignature(request, rawBody) {
    const accessToken = await this.getAccessToken();
    const res = await fetch(`${PAYPAL_API_BASE}/v1/notifications/verify-webhook-signature`, {
      method: "POST",
      headers: { Authorization: `Bearer ${accessToken}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        transmission_id: request.headers.get("paypal-transmission-id"),
        transmission_time: request.headers.get("paypal-transmission-time"),
        cert_url: request.headers.get("paypal-cert-url"),
        auth_algo: request.headers.get("paypal-auth-algo"),
        transmission_sig: request.headers.get("paypal-transmission-sig"),
        webhook_id: this.env.PAYPAL_WEBHOOK_ID,
        webhook_event: JSON.parse(rawBody)
      })
    });
    if (!res.ok) return false;
    return (await res.json()).verification_status === "SUCCESS";
  }

  async captureOrder(orderId) {
    const accessToken = await this.getAccessToken();
    const res = await fetch(`${PAYPAL_API_BASE}/v2/checkout/orders/${orderId}/capture`, {
      method: "POST",
      headers: { Authorization: `Bearer ${accessToken}`, "Content-Type": "application/json" }
    });
    if (!res.ok) return { error: ErrorCodes.PAYMENT_VERIFICATION_FAILED };
    return { data: await res.json() };
  }

  /**
   * القلب: CREATED→APPROVED (ضمنيًا عبر PayPal)→CAPTURED→VERIFIED→LICENSE_ISSUED.
   * Idempotent عبر captureId (PRIMARY KEY لجدول payment_events نفسه).
   * يُستدعى من مساري Capture المباشر والـWebhook بنفس المنطق تمامًا.
   */
  async processCompletedCapture({ captureId, orderId, offerKey, amount, currency, buyerEmail }) {
    const existing = await this.paymentRepo.findByCaptureId(captureId);
    if (existing) {
      await this.securityEventRepo.record("payment_duplicate_ignored", {});
      return { alreadyProcessed: true, licenseId: existing.license_id };
    }

    await this.paymentRepo.create({
      captureId, orderId, planKey: offerKey, amount, buyerEmail, status: PaymentStatus.CAPTURED
    });

    const offer = getOffer(offerKey);
    if (!matchesOffer(offer, amount, currency)) {
      await this.paymentRepo.setStatus(captureId, PaymentStatus.FAILED);
      await this.securityEventRepo.record("payment_rejected_amount_mismatch", {});
      return { error: ErrorCodes.PAYMENT_AMOUNT_MISMATCH };
    }

    await this.paymentRepo.setStatus(captureId, PaymentStatus.VERIFIED);
    await this.securityEventRepo.record("payment_verified", {});

    const licenseId = generateSecureId("license");
    const licenseKey = generateSecureLicenseKey();
    const createdAt = new Date().toISOString().slice(0, 16);
    const expiryDate = new Date(Date.now() + offer.durationDays * 24 * 60 * 60 * 1000).toISOString().slice(0, 16);
    const username = buyerEmail ? buyerEmail.split("@")[0] : "customer";

    await this.licenseRepo.create({
      id: licenseId, username, key: licenseKey, createdAt, expiryDate,
      devices: 1, planId: offer.planId, email: buyerEmail
    });
    await this.securityEventRepo.record("license_created", { licenseId });

    await this.paymentRepo.linkLicenseAndIssue(captureId, licenseId);

    const emailResult = await this.sendLicenseEmail({
      toEmail: buyerEmail, licenseKey, username, createdAt, expiryDate, offerLabel: offer.label
    });

    return { alreadyProcessed: false, licenseId, licenseKey, expiryDate, emailSent: emailResult.sent };
  }

  /**
   * البند 8: Refund/Reversal/Dispute — نُبطل الترخيص المرتبط تلقائيًا فور
   * استرجاع الأموال، لأن الوصول لم يعد مستحقًا. هذا افتراض عملي صريح
   * (استرداد المال = إلغاء الوصول) — عدّله إن أردت سلوكًا مختلفًا لاحقًا.
   */
  async processRefundOrReversal(captureId, newStatus) {
    const payment = await this.paymentRepo.findByCaptureId(captureId);
    if (!payment) return { error: ErrorCodes.PAYMENT_NOT_FOUND };

    await this.paymentRepo.setStatus(captureId, newStatus);
    await this.securityEventRepo.record(`payment_${newStatus.toLowerCase()}`, { licenseId: payment.license_id });

    if (payment.license_id) {
      await this.licenseRepo.revoke(payment.license_id);
      await this.securityEventRepo.record("license_revoked_due_to_refund", { licenseId: payment.license_id });
    }

    return { success: true };
  }
}
