import { hashBiosId, timingSafeEqual } from "../shared/crypto.js";
import { ErrorCodes } from "../shared/errors.js";
import { LicenseStatus } from "./licenseStatusService.js";

/**
 * SessionService
 * ----------------------------------------------------------------------------
 * "validate": تحقق للقراءة فقط (تُستخدَم أمام أي ميزة محمية)، لا تُصدر توكنًا جديدًا.
 * "renew": نفس تحقق validate بالكامل، ثم تُصدر توكنًا جديدًا وتُبطل (منطقيًا)
 *          القديم بانتهائه الطبيعي القريب جدًا (≤20 دقيقة).
 *
 * كلاهما يُعيد قراءة الترخيص من D1 في كل مرة — لا يوجد أي "تمرير" على حساب
 * الثقة بمحتوى التوكن نفسه بخصوص حالة الترخيص.
 */
export class SessionService {
  constructor({ sessionTokenService, licenseRepo, statusService, securityEventRepo }) {
    this.sessionTokenService = sessionTokenService;
    this.licenseRepo = licenseRepo;
    this.statusService = statusService;
    this.securityEventRepo = securityEventRepo;
  }

  async _verifyFull(bearerToken, rawBiosId) {
    const verified = await this.sessionTokenService.verifySignatureAndFormat(bearerToken);
    if (verified.error === "expired") return { error: ErrorCodes.TOKEN_EXPIRED };
    if (verified.error) return { error: ErrorCodes.INVALID_TOKEN };

    const { claims } = verified;
    const license = await this.licenseRepo.findById(claims.lid);
    if (!license) return { error: ErrorCodes.INVALID_LICENSE };

    const status = this.statusService.computeStatus(license);
    if (status === LicenseStatus.REVOKED) return { error: ErrorCodes.LICENSE_REVOKED };
    if (status === LicenseStatus.EXPIRED) return { error: ErrorCodes.LICENSE_EXPIRED };
    if (status === LicenseStatus.PENDING) return { error: ErrorCodes.PENDING_ACTIVATION };

    // الجهاز الذي يحمل التوكن يجب أن يطابق نفس بصمة BIOS المُخزَّنة الآن في D1
    // (وليس فقط ما كان مخزَّنًا في التوكن وقت إصداره) — هذا يمنع استخدام توكن
    // من جهاز آخر حتى لو سُرق التوكن نفسه (البند 15: "كيف يمنع من جهاز آخر").
    const currentBiosHash = await hashBiosId(rawBiosId);
    if (!timingSafeEqual(license.biosId, currentBiosHash) || !timingSafeEqual(claims.bh, currentBiosHash)) {
      return { error: ErrorCodes.DEVICE_NOT_AUTHORIZED };
    }

    return { valid: true, license, status, claims };
  }

  async validate(bearerToken, rawBiosId) {
    const result = await this._verifyFull(bearerToken, rawBiosId);
    if (result.error) {
      await this.securityEventRepo.record("token_rejected", {});
      return result;
    }
    return result;
  }

  async renew(bearerToken, rawBiosId) {
    const result = await this._verifyFull(bearerToken, rawBiosId);
    if (result.error) {
      await this.securityEventRepo.record("token_renewal_rejected", { licenseId: null });
      return result;
    }

    const { token, expiresAt } = await this.sessionTokenService.issue({
      licenseId: result.license.id,
      planId: result.license.planId,
      biosHash: result.claims.bh
    });

    await this.securityEventRepo.record("token_renewed", { licenseId: result.license.id });
    return { token, expiresAt, planId: result.license.planId };
  }
}
