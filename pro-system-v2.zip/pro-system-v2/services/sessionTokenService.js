import { hmacSign, timingSafeEqual, stringToBase64Url, base64UrlToString, generateJti } from "../shared/crypto.js";

const SESSION_TTL_MS = 20 * 60 * 1000; // 20 دقيقة — منتصف نطاق 15-30 المطلوب

/**
 * SessionTokenService
 * ----------------------------------------------------------------------------
 * شكل التوكن: <kid>.<claims_base64url>.<signature>
 * claims = { lid, pid, bh, iat, exp, jti }
 *
 * ⚠️ التوكن نفسه ليس مصدر الحقيقة — كل تجديد وكل تحقق (validate) يُعاد فيه
 * قراءة حالة الترخيص من D1 مباشرة (انظر sessionService.renew/validate).
 * هذا الملف مسؤول فقط عن الشكل/التوقيع/الصلاحية الزمنية.
 */
export class SessionTokenService {
  constructor(keyManager) {
    this.keyManager = keyManager;
  }

  async issue({ licenseId, planId, biosHash }) {
    const now = Date.now();
    const claims = {
      lid: licenseId,
      pid: planId,
      bh: biosHash,
      iat: now,
      exp: now + SESSION_TTL_MS,
      jti: generateJti()
    };

    const kid = this.keyManager.getActiveKid();
    const claimsB64 = stringToBase64Url(JSON.stringify(claims));
    const signingInput = `${kid}.${claimsB64}`;
    const signature = await hmacSign(this.keyManager.getActiveSecret(), signingInput);

    return { token: `${signingInput}.${signature}`, expiresAt: claims.exp, jti: claims.jti };
  }

  /**
   * يتحقق من: شكل صحيح، kid معروف، توقيع صحيح، لم تنتهِ صلاحيته زمنيًا.
   * لا يتحقق من حالة الترخيص في D1 — هذا مسؤولية الطبقة الأعلى (validationService).
   */
  async verifySignatureAndFormat(token) {
    if (!token || typeof token !== "string") return { error: "malformed" };

    const parts = token.split(".");
    if (parts.length !== 3) return { error: "malformed" };
    const [kid, claimsB64, signature] = parts;

    const secret = this.keyManager.getVerificationSecret(kid);
    if (!secret) return { error: "unknown_kid" };

    const expectedSignature = await hmacSign(secret, `${kid}.${claimsB64}`);
    if (!timingSafeEqual(signature, expectedSignature)) return { error: "bad_signature" };

    let claims;
    try {
      claims = JSON.parse(base64UrlToString(claimsB64));
    } catch {
      return { error: "malformed" };
    }

    if (!claims.exp || Date.now() > claims.exp) return { error: "expired", claims };

    return { claims };
  }
}
