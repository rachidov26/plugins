export function createEmailSender(env) {
  return async function sendLicenseEmail({ toEmail, licenseKey, username, createdAt, expiryDate, offerLabel }) {
    if (!toEmail) return { sent: false, reason: "no_email_available" };

    try {
      const res = await fetch("https://api.resend.com/emails", {
        method: "POST",
        headers: { Authorization: `Bearer ${env.RESEND_API_KEY}`, "Content-Type": "application/json" },
        body: JSON.stringify({
          from: "Veltrix32 <noreply@yourdomain.com>", // ⚠️ استبدل بنطاقك المتحقَّق في Resend
          to: [toEmail],
          subject: `مرحبًا بك في ${offerLabel} — مفتاح ترخيصك جاهز`,
          html: `
            <div dir="rtl" style="font-family: Arial, sans-serif; max-width: 480px; margin: auto;">
              <h2>شكرًا لاشتراكك في ${offerLabel}${username ? `، ${username}` : ""}</h2>
              <p>مفتاح الترخيص الخاص بك:</p>
              <p style="font-size:20px; font-weight:bold; background:#f2f2f2; padding:14px; border-radius:8px; text-align:center; letter-spacing:1px;">
                ${licenseKey}
              </p>
              <table style="width:100%; font-size:14px; color:#555; margin-top:16px;">
                <tr><td>تاريخ الإنشاء</td><td style="text-align:left;">${createdAt}</td></tr>
                <tr><td>تاريخ الانتهاء</td><td style="text-align:left;">${expiryDate}</td></tr>
              </table>
              <h3 style="margin-top:24px;">خطوات التفعيل</h3>
              <ol style="font-size:14px; color:#333;">
                <li>افتح التطبيق</li>
                <li>أدخل مفتاح الترخيص + نفس البريد الإلكتروني المستخدم في الدفع</li>
                <li>سيتم ربط الترخيص بجهازك تلقائيًا عند أول تفعيل</li>
              </ol>
            </div>`
        })
      });
      return { sent: res.ok, reason: res.ok ? null : `resend_error_${res.status}` };
    } catch {
      return { sent: false, reason: "resend_network_error" };
    }
  };
}
